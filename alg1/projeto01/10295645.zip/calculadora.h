double atod(char* string); //funcao que pode ser util para usar outras vezes

double resolve_conta(char* linha, double* res); //funcao principal do trabalho
